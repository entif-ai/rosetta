# Prompt Templates

## Initial 25-Issue Batch Triage

```text
You are ranking one fixed batch of GitHub issues for immediate implementation order.

Goal:
Rank these issues only against each other. Use A-Y for actionable issues. Do not use Z as a normal priority rank.

Rules:
1. Rank only within this batch.
2. Prefer unblocked issues over blocked issues.
3. Prefer issues that unblock other issues.
4. Prefer self-contained issues with clear acceptance criteria.
5. If an issue appears blocked and the blocker is known, mark it BLOCKED and name the blocker.
6. If an issue appears blocked but the blocker is unknown or missing, mark it NEEDS_BLOCKER.
7. If an issue is too large/vague, mark it NEEDS_SPLIT or NEEDS_CLARIFICATION.
8. Do not invent blockers.
9. Keep summaries and rationales to one sentence.
10. Output only the table and final notes.

Output columns:
Rank, Issue Number, Status, Title, One-sentence summary, Why this rank, Known blocker, Confidence.

Status values:
ACTIONABLE, BLOCKED, NEEDS_BLOCKER, NEEDS_SPLIT, NEEDS_CLARIFICATION, DUPLICATE_CANDIDATE.

Final notes:
- Best issue in batch:
- Close runner-up:
- Blocked/needs-blocker issues:
- Issues needing split/clarification:
```

## Active Bucket Rerank

```text
You are reranking one active priority bucket from a bucketed demotion cascade.

Goal:
Choose exactly one issue as the next issue to work. Then order the losing issues by finish position so they can be demoted.

Rules:
1. Compare only the issues provided in this bucket.
2. Select the issue that should be worked next.
3. Prefer unblocked issues that unblock other work.
4. Prefer foundational or sequencing-critical issues.
5. Prefer issues with clear acceptance criteria.
6. Do not choose blocked or unclear issues unless every issue is blocked/unclear.
7. Keep rationales to one sentence.
8. Output only the required table and winner summary.

Output columns:
Finish, Issue Number, Title, Why this finish, Destination.

Destination rules:
1st = DO_NOW.
2nd = demote one bucket.
3rd = demote two buckets.
4th = demote three buckets.
Continue this pattern.

Winner summary:
- Winner:
- Why winner beats runner-up:
- Any issues to move out of active ranking into BLOCKED / NEEDS_BLOCKER / NEEDS_SPLIT / NEEDS_CLARIFICATION:
```

## Compact GitHub Fetch Instructions

```text
Fetch open repository issues ordered oldest to newest. Exclude pull requests. Create fixed batches of 25 issue numbers. For each issue, collect title, body, labels, explicit dependencies or linked issue references, and only the comments needed to identify blockers. Do not mutate GitHub labels or issues unless explicitly instructed.
```
