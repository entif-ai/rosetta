# Bucketed Demotion Cascade Protocol

## Goal

Select the next GitHub issue to work from a large backlog while keeping every model pass bounded to 25 issues or fewer.

## Definitions

- **Issue manifest**: the frozen list of open issues being triaged.
- **Initial batch**: a group of up to 25 issues, usually oldest-to-newest from the frozen manifest.
- **Bucket**: a priority container named by rank, e.g. `A`, `B`, `C`, ..., `Y`, `A2`, `B2`.
- **Active bucket**: the highest-priority non-empty bucket currently being reranked.
- **Winner**: the first-place issue in a bucket rerank. This is selected as the next issue to work.
- **Loser demotion**: each losing issue moves down by its finish position minus one.

## Initial Batch Ranking

Each initial batch is ranked locally:

- best actionable issue -> `A`
- second actionable issue -> `B`
- continue through `Y`
- blocked/unrankable issues -> separate state, not a normal rank

Do not compare across batches during the initial pass.

## Bucket Creation

After all initial batches are ranked:

- all local `A` issues enter bucket `A`
- all local `B` issues enter bucket `B`
- all local `C` issues enter bucket `C`
- continue through `Y`

Blocked or unrankable items are separated into `BLOCKED`, `NEEDS_BLOCKER`, `NEEDS_SPLIT`, `NEEDS_CLARIFICATION`, or `DUPLICATE_CANDIDATE`.

## Work Loop

1. Choose the highest non-empty active bucket.
2. Rerank only that bucket.
3. Select the first-place issue as `DO_NOW`.
4. Remove the winner from the bucket system.
5. Demote every loser:
   - 2nd place moves down 1 bucket
   - 3rd place moves down 2 buckets
   - 4th place moves down 3 buckets
   - etc.
6. If a target bucket is full, spill into the next lower bucket.
7. Repeat after the selected issue is completed, skipped, or manually overridden.

## Example

A bucket contains 5 issues:

| Finish | Issue |
|---:|---:|
| 1 | #100 |
| 2 | #200 |
| 3 | #300 |
| 4 | #400 |
| 5 | #500 |

Result:

- #100 -> selected now
- #200 -> B
- #300 -> C
- #400 -> D
- #500 -> E

If bucket `C` is full, #300 spills to `D`, then `E`, etc. until a non-full bucket is found.

## Blocker Rules

- `BLOCKED`: a specific blocker is known.
- `NEEDS_BLOCKER`: the issue seems blocked but no blocker issue is known.
- `NEEDS_SPLIT`: too large to finish as one task.
- `NEEDS_CLARIFICATION`: ambiguous or missing acceptance criteria.
- `DUPLICATE_CANDIDATE`: likely duplicate, but not confirmed.

Do not use blocked issues in active priority buckets unless the user explicitly asks to prioritize blocker cleanup.

## Tie-Breaking

If two issues appear equal, prefer:

1. issue that unblocks more issues
2. issue with clearer acceptance criteria
3. issue with lower implementation risk
4. older issue
5. smaller self-contained issue
