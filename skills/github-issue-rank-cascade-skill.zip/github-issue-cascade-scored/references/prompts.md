# Prompt Templates

## Initial 25-Issue Batch Triage

```text
You are ranking one fixed batch of GitHub issues for immediate implementation order.

Goal:
Rank these issues only against each other. Use A-Y for actionable issues. Do not use Z as a normal priority rank.

Rules:
1. Rank only within this batch.
2. Use the rubric in references/ranking-rubric.md. Do not invent a new priority strategy.
3. Prefer SDLC prerequisites before downstream implementation: PRD, journey, domain model, schema, contract, AuthN/AuthZ, rights matrix, design/view requirements, interface, test harness, then feature code.
4. Demote cart-before-horse implementation that should wait for a PRD, journey, schema, contract, permission model, design, interface, test harness, split, or research spike.
5. Prefer self-contained issues with clear acceptance criteria.
6. If an issue appears blocked and the blocker is known, mark it BLOCKED and name the blocker.
7. If an issue appears blocked but the blocker is unknown or missing, mark it NEEDS_BLOCKER.
8. If an issue is too large/vague, mark it NEEDS_SPLIT or NEEDS_CLARIFICATION.
9. If implementation requires research first, mark it NEEDS_CLARIFICATION or recommend a spike.
10. Do not invent blockers.
11. Keep summaries and rationales to one sentence.
12. Output only the table and final notes.

Output columns:
Rank, Issue Number, Status, Title, One-sentence summary, Why this rank, SDLC signal, Known blocker, Confidence.

SDLC signal should be one short tag such as prd-needed, journey-needed, domain-model, schema-first, contract-first, authz-first, design-first, interface-first, spike-first, split-first, test-harness-first, implementation-ready, low-hanging-safe, or rework-risk.

Status values:
ACTIONABLE, BLOCKED, NEEDS_BLOCKER, NEEDS_SPLIT, NEEDS_CLARIFICATION, DUPLICATE_CANDIDATE.

Final notes:
- Best issue in batch:
- Close runner-up:
- Blocked/needs-blocker issues:
- Issues needing split/clarification:
```

## Active Bucket Rerank

```text
You are reranking one active priority bucket from a bucketed demotion cascade.

Goal:
Choose exactly one issue as the next issue to work. Then order the losing issues by finish position so they can be demoted.

Rules:
1. Compare only the issues provided in this bucket.
2. Use the rubric in references/ranking-rubric.md. Do not invent a new priority strategy.
3. Select the issue that should be worked next.
4. Prefer unblocked SDLC prerequisite issues that prevent cart-before-horse implementation: PRD, journey, domain model, schema, contract, AuthN/AuthZ, rights matrix, design/view requirements, interface, or test harness.
5. Prefer issues with clear acceptance criteria.
6. Demote issues that need a missing upstream artifact, spike, blocker, split, or clarification before implementation.
7. Do not choose blocked or unclear issues unless every issue is blocked/unclear.
8. Keep rationales to one sentence.
9. Output only the required table and winner summary.

Output columns:
Finish, Issue Number, Title, Why this finish, SDLC signal, Destination.

Destination rules:
1st = DO_NOW.
2nd = demote one bucket.
3rd = demote two buckets.
4th = demote three buckets.
Continue this pattern.

Winner summary:
- Winner:
- Why winner beats runner-up:
- Any issues to move out of active ranking into BLOCKED / NEEDS_BLOCKER / NEEDS_SPLIT / NEEDS_CLARIFICATION:
```

## Compact GitHub Fetch Instructions

```text
Fetch open repository issues ordered oldest to newest. Exclude pull requests. Create fixed batches of 25 issue numbers. For each issue, collect title, body, labels, explicit dependencies or linked issue references, and only the comments needed to identify blockers. Do not mutate GitHub labels or issues unless explicitly instructed.
```

## Scored Classification Mode

Use this when a harness can run `scripts/score_issues.py`. The model should classify and score; the script should rank.

```text
You are classifying GitHub issues for semi-deterministic prioritization.

Do not freely rank by intuition. For each issue, output controlled JSON only.

Use references/ranking-rubric.md and references/scoring-matrix.md.

For each issue choose:
- status: ACTIONABLE, BLOCKED, NEEDS_BLOCKER, NEEDS_SPLIT, NEEDS_CLARIFICATION, or DUPLICATE_CANDIDATE
- sdlc_class: prd_spec, user_journey, domain_model, schema_contract, auth_rights_policy, ux_view_design, interface_adapter, test_harness, spike_research, split_decomposition, implementation_feature, bug_fix, integration_ops, or polish_refactor
- signals: only short known tags such as prd-needed, journey-needed, domain-model, schema-first, contract-first, authz-first, design-first, interface-first, spike-first, split-first, test-harness-first, implementation-ready, low-hanging-safe, rework-risk, blocked-known, blocked-unknown
- scores: integers 0-4 for readiness, prerequisite_power, rework_prevention, blocker_leverage, reuse_surface, milestone_demand, effort_fit, confidence

Rules:
1. Use explicit issue evidence. Do not invent blockers.
2. If a downstream implementation lacks a prerequisite artifact, mark NEEDS_BLOCKER or NEEDS_CLARIFICATION and name the missing prerequisite.
3. A spec/schema/spike/split issue may be ACTIONABLE even if downstream code is blocked.
4. Keep summary and rationale to one sentence each.
5. Output JSON only.

Output shape:
{
  "batch_id": "...",
  "items": [
    {
      "issue_number": 123,
      "title": "...",
      "status": "ACTIONABLE",
      "sdlc_class": "schema_contract",
      "signals": ["schema-first"],
      "scores": {
        "readiness": 3,
        "prerequisite_power": 3,
        "rework_prevention": 3,
        "blocker_leverage": 2,
        "reuse_surface": 2,
        "milestone_demand": 2,
        "effort_fit": 2,
        "confidence": 3
      },
      "missing_prerequisite": null,
      "known_blocker": null,
      "summary": "...",
      "rationale": "..."
    }
  ]
}
```
