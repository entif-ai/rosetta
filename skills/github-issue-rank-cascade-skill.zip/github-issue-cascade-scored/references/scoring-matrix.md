# Semi-Deterministic Scoring Matrix

Use this reference when the harness can support a structured classifier + script flow. The goal is to stop weak models from inventing ranking logic. The model classifies each issue into controlled fields and small numeric scores. The script computes the order.

This matrix is intentionally a Promethean prototype, not a complete product strategy framework.

## Operating Model

1. The LLM does **classification**, not open-ended prioritization.
2. It chooses from a small enum list and assigns 0-4 scores using the definitions below.
3. The scoring script computes `priority_score` and sorts items.
4. The cascade script applies bucket demotion.
5. Humans tune weights after seeing outcomes.

In plain words: do not ask the intern-model to philosophize. Hand it a clipboard with boxes to tick.

## Controlled SDLC Classifications

Use exactly one primary `sdlc_class` per issue.

| `sdlc_class` | Meaning | Typical priority posture |
|---|---|---|
| `prd_spec` | Defines problem, scope, acceptance intent, success criteria | high when missing for downstream work |
| `user_journey` | Defines workflow, actor path, state transitions, user/system steps | high before UI/API implementation |
| `domain_model` | Defines entities, vocabulary, lifecycle states, relationships | high before schemas and logic |
| `schema_contract` | Defines data model, API shape, event payload, validation, migration | high before CRUD/UI/jobs |
| `auth_rights_policy` | Defines identity, session, RBAC/ABAC, permissions, guard policy | high before protected features/admin UI |
| `ux_view_design` | Defines IA, wireframe, view contract, component states, navigation | high before UI implementation |
| `interface_adapter` | Defines service boundary, provider adapter, port, client, protocol | high before integrations |
| `test_harness` | Defines fixtures, conformance tests, mocks, evaluation harness | high before risky implementation |
| `spike_research` | Bounded research needed to choose an approach or de-risk uncertainty | high when downstream work would guess |
| `split_decomposition` | Breaks a broad epic into smaller action-ready tasks | high when issue is too large |
| `implementation_feature` | Implements behavior, screen, endpoint, job, workflow | high only when prerequisites exist |
| `bug_fix` | Fixes a broken behavior | high when user/blocker/security impact is clear |
| `integration_ops` | Integration, migration, observability, deployment, hardening | high near release or when blocking reliability |
| `polish_refactor` | Cleanup, optimization, cosmetic polish, internal refactor | lower unless it unblocks or prevents major rework |

Do not create new classes during triage. If none fits, use `spike_research` or `split_decomposition` and explain why.

## Readiness Status

Use one `status`.

- `ACTIONABLE`: can be worked now as written.
- `BLOCKED`: a known prerequisite issue exists.
- `NEEDS_BLOCKER`: a prerequisite is missing but no blocker issue is identified.
- `NEEDS_SPLIT`: too broad or multi-phase as written.
- `NEEDS_CLARIFICATION`: unclear intent, acceptance criteria, or expected artifact.
- `DUPLICATE_CANDIDATE`: likely duplicate.

Only `ACTIONABLE` items enter A-Y buckets. A spec, spike, schema, or split issue can be `ACTIONABLE` even if the downstream implementation is blocked.

## Score Fields

Score each field from 0 to 4. Use evidence from the issue. Do not infer grand strategy from thin air.

### `readiness`

| Score | Meaning |
|---:|---|
| 0 | cannot act; unclear |
| 1 | rough idea only |
| 2 | enough to draft/split/spec |
| 3 | mostly clear acceptance target |
| 4 | crisp, small, ready now |

### `prerequisite_power`

How upstream is this artifact in SDLC dependency order?

| Score | Meaning |
|---:|---|
| 0 | polish/refactor after function exists |
| 1 | downstream implementation |
| 2 | design/interface/test support |
| 3 | schema/contract/auth/domain prerequisite |
| 4 | PRD/journey/core policy/spine prerequisite needed by many later tasks |

### `rework_prevention`

Would doing this now prevent wrong work later?

| Score | Meaning |
|---:|---|
| 0 | no meaningful rework risk |
| 1 | small cleanup or alignment benefit |
| 2 | reduces moderate ambiguity |
| 3 | likely prevents wrong schema/design/API/auth choices |
| 4 | must happen first or downstream work may be thrown away |

### `blocker_leverage`

How many things does this unblock?

| Score | Meaning |
|---:|---|
| 0 | blocks nothing known |
| 1 | may help one nearby task |
| 2 | helps several related tasks |
| 3 | unblocks an epic/milestone slice |
| 4 | foundational blocker for many issues or the whole build path |

### `reuse_surface`

How broadly reusable is the result?

| Score | Meaning |
|---:|---|
| 0 | one-off |
| 1 | narrow local reuse |
| 2 | reusable within one feature area |
| 3 | reusable across multiple modules/products |
| 4 | foundational primitive/pattern/contract |

### `milestone_demand`

How tied is this to current goals, demos, customer asks, or operational need?

| Score | Meaning |
|---:|---|
| 0 | no current demand signal |
| 1 | nice-to-have |
| 2 | relevant to known milestone |
| 3 | important to current milestone/demo/user pain |
| 4 | urgent blocker, bug, SLA, customer ask, or decisive demo enabler |

### `effort_fit`

Small, finishable work scores higher. This rewards shippable slices, not tiny trivia.

| Score | Meaning |
|---:|---|
| 0 | giant/unclear epic |
| 1 | large, needs split |
| 2 | moderate, feasible |
| 3 | small clean task |
| 4 | tiny but meaningful clean win |

### `confidence`

How confident is the classifier based on explicit issue evidence?

| Score | Meaning |
|---:|---|
| 0 | guessing |
| 1 | weak evidence |
| 2 | plausible |
| 3 | clear evidence |
| 4 | explicit labels/body/links support classification |

## Default Weights

The scoring script uses these defaults:

```json
{
  "readiness": 2.0,
  "prerequisite_power": 3.0,
  "rework_prevention": 3.0,
  "blocker_leverage": 3.0,
  "reuse_surface": 1.5,
  "milestone_demand": 2.0,
  "effort_fit": 1.5,
  "confidence": 0.75
}
```

This intentionally weights SDLC sequencing above generic business value.

## Penalties

The script applies these default penalties:

```json
{
  "NEEDS_CLARIFICATION": -8,
  "NEEDS_SPLIT": -7,
  "NEEDS_BLOCKER": -10,
  "BLOCKED": -12,
  "DUPLICATE_CANDIDATE": -12
}
```

Non-actionable items still receive a diagnostic score, but do not enter active priority buckets.

## Required Model Output

When using scored mode, each issue should become this object:

```json
{
  "issue_number": 123,
  "title": "Short title",
  "status": "ACTIONABLE",
  "sdlc_class": "schema_contract",
  "signals": ["schema-first", "rework-risk"],
  "scores": {
    "readiness": 3,
    "prerequisite_power": 3,
    "rework_prevention": 3,
    "blocker_leverage": 2,
    "reuse_surface": 3,
    "milestone_demand": 2,
    "effort_fit": 2,
    "confidence": 3
  },
  "missing_prerequisite": null,
  "known_blocker": null,
  "summary": "Defines the API/data contract needed by later work.",
  "rationale": "Ranks high because downstream implementation would otherwise guess the contract."
}
```

## Deterministic Ranking Rule

For `ACTIONABLE` items:

1. Compute weighted score.
2. Sort descending by weighted score.
3. Tie-break by earlier SDLC class order:
   `prd_spec`, `user_journey`, `domain_model`, `schema_contract`, `auth_rights_policy`, `ux_view_design`, `interface_adapter`, `test_harness`, `spike_research`, `split_decomposition`, `implementation_feature`, `bug_fix`, `integration_ops`, `polish_refactor`.
4. Tie-break by lower issue number if available.
5. Assign A-Y in sorted order.

For non-actionable items, keep them in separate state buckets.

## Tuning Guidance

After several runs, tune weights instead of rewriting prompts.

- If too much vague architecture rises, increase `readiness` and `effort_fit`.
- If too many downstream UI tasks rise early, increase `prerequisite_power` and `rework_prevention`.
- If small trivia rises over important blockers, increase `blocker_leverage` and `milestone_demand`.
- If research spikes dominate, require `spike_research` to be bounded and raise `readiness` threshold.
