# Ranking Rubric

Use this rubric whenever ranking issues inside an initial batch or reranking an active bucket. The goal is not to pick the most interesting issue. The goal is to pick the issue that should be worked next according to basic SDLC dependency order, project leverage, and readiness.

For weak models: treat this as a checklist, not an essay prompt. Prefer explicit evidence in the issue title/body/labels/comments. Do not invent hidden dependencies.

## Core Doctrine

Rank issues by **cart-before-horse risk** first, then leverage.

An issue is high priority when it creates a missing prerequisite that many later issues need. An issue is lower priority when it tries to build a downstream artifact before its prerequisite artifacts exist.

In plain words: do not build the rights-management UI before the roles/permissions model exists; do not build a user profile view before knowing the user/profile schema and journey; do not build protected routes before the auth/session/authorization contract is clear.

## SDLC Artifact Order

Use this default dependency ladder. Earlier artifacts usually outrank later artifacts when both appear in the same bucket.

1. **Problem / PRD / acceptance intent**: define what problem, user, behavior, and success condition the work serves.
2. **User journeys / workflows**: define who does what, in what order, and what state changes occur.
3. **Domain model / vocabulary**: define core entities, actors, states, relationships, and lifecycle concepts.
4. **Data schemas / contracts**: define stored data, API shapes, event payloads, validation rules, and migrations.
5. **AuthN / AuthZ / rights model**: define identity, roles, permissions, policies, ownership, and access boundaries before protected features or admin UIs.
6. **UX information architecture / wireframes / view requirements**: define screens, components, navigation, states, empty/error/loading cases, and interactions.
7. **Implementation scaffolding / adapters / interfaces**: define boundaries, ports, service interfaces, factories, clients, and test harnesses.
8. **Feature implementation**: build the actual behavior, screens, endpoints, jobs, or workflows.
9. **Integration / migration / observability / hardening**: connect, deploy, measure, secure, and make it reliable.
10. **Polish / optimization / refactor / cleanup**: improve what already works.

This is not a rigid waterfall. Sometimes design mocks expose missing schema fields; sometimes schema work exposes missing journey states. When two artifacts inform each other, rank the issue that produces the **smallest useful prerequisite artifact** first.

## Cart-Before-Horse Demotion Rules

Demote or move an issue out of active ranking when it tries to build downstream work before required upstream artifacts exist.

| If the issue wants to build... | But this is missing... | Prefer first... |
|---|---|---|
| user profile screen | user/profile schema or journey | schema/journey issue |
| preferences/settings UI | settings schema, defaults, save/reset behavior | schema + UX state spec |
| rights/admin UI | RBAC/ABAC/policy matrix | rights model issue |
| protected route or permissioned action | AuthN/AuthZ/session contract | auth contract issue |
| CRUD API | entity schema, validation rules, ownership rules | schema/contract issue |
| frontend form | fields, validation, submit behavior, error states | wireframe/view contract |
| event consumer/job | event schema, idempotency, retry/DLQ semantics | event contract issue |
| provider integration | adapter interface, secrets model, failure modes | interface/spike issue |
| autonomous agent action | guard/admission policy, audit/receipt expectation | policy/receipt issue |
| large epic implementation | decomposed subtasks and acceptance criteria | split/spec issue |

## Status Classification Rules

Use these statuses consistently:

- `ACTIONABLE`: can be worked now as written.
- `BLOCKED`: a known prerequisite issue exists and should be done first.
- `NEEDS_BLOCKER`: a prerequisite is clearly missing, but no blocker issue is identified.
- `NEEDS_SPLIT`: too large or multi-phase to complete cleanly as one issue.
- `NEEDS_CLARIFICATION`: intent, acceptance criteria, or required artifact is unclear.
- `DUPLICATE_CANDIDATE`: likely duplicates another issue.

A spec, schema, spike, or decomposition task can be `ACTIONABLE` even when the downstream implementation is not.

## SDLC Signal Tags

When outputting a ranking, include one short signal phrase. Use one of these when possible:

- `prd-needed`
- `journey-needed`
- `domain-model`
- `schema-first`
- `contract-first`
- `authz-first`
- `design-first`
- `interface-first`
- `spike-first`
- `split-first`
- `test-harness-first`
- `implementation-ready`
- `low-hanging-safe`
- `rework-risk`
- `blocked-known`
- `blocked-unknown`

## Scoring Axes

Score each actionable issue from 0 to 3 on these axes. Use the scores to guide ordering, but do not output long math unless the user asks.

| Axis | 0 | 1 | 2 | 3 |
|---|---|---|---|---|
| **Prerequisite position** | downstream/polish | implementation | schema/contract/design | PRD/journey/domain/policy prerequisite |
| **Cart-before-horse risk** | no ordering risk | mild risk | likely rework if done late/wrong | must happen first to avoid major undo |
| **Blocker leverage** | blocks nothing known | may help later | helps multiple later issues | directly blocks many issues or milestone |
| **Spec/action readiness** | unclear | rough | mostly clear | crisp enough now |
| **Research/spike need** | unknown and risky | likely needs spike | bounded uncertainty | no spike needed or issue itself is the spike |
| **Reuse/surface area** | one-off | limited reuse | reusable in several places | foundational primitive |
| **Immediate utility** | little direct utility | nice-to-have | useful soon | immediate dev/product/operator value |
| **Implementation size fit** | too large as written | large but splittable | moderate | small clean win |

## Priority Interpretation

Promote issues that:

- create missing prerequisite artifacts;
- prevent future rework;
- unblock multiple implementation issues;
- define schemas, contracts, policies, or journeys needed by many later issues;
- are small enough to complete cleanly;
- turn vague downstream work into crisp subtasks.

Demote or remove from active ranking when:

- implementation depends on an absent schema/contract/journey/design;
- the issue is too broad to finish cleanly;
- acceptance criteria are vague;
- it requires research before implementation;
- it is polish/refactor work that does not unblock current build flow.

## Tie-Breaking

If issues seem equal, prefer in this order:

1. earlier SDLC prerequisite artifact;
2. higher cart-before-horse risk reduction;
3. higher blocker leverage;
4. clearer acceptance criteria;
5. lower research uncertainty, unless the issue itself is a spike;
6. broader reuse/surface area;
7. smaller clean completion size;
8. immediate utility;
9. older issue.

## Entif/Rosetta Default Bias

For Entif/Rosetta and similar early-stage, spec-heavy repositories:

1. Prefer issues that define the **spine**: manifests, schemas, contracts, IDs, run state, receipts, guard/policy boundaries, pack layout, and test fixtures.
2. Prefer specs that make implementation safe over implementation that would guess at architecture.
3. Prefer small schema/contract/journey/design artifacts over broad epics.
4. Prefer auth/rights/policy modeling before protected UIs, autonomous actions, or admin workflows.
5. Prefer adapter/interface definitions before provider-specific integrations.
6. Prefer tests/fixtures/conformance examples before risky engine logic.
7. Prefer low-hanging implementation only when it is clearly self-contained and unlikely to conflict with the emerging architecture.

## Output Discipline for Weak Models

Do not invent elaborate strategy. Use this rubric as a quiet checklist.

For each issue, output at most:

- one sentence summary;
- one sentence rank rationale;
- one SDLC signal tag;
- optional short score tuple, e.g. `prereq=3, rework=2, blocker=2, ready=2, spike=3, reuse=2, utility=1, size=2`.

If an issue is not actionable implementation but should become a prerequisite issue, classify it as `NEEDS_BLOCKER`, `NEEDS_SPLIT`, or `NEEDS_CLARIFICATION` and state the missing prerequisite in one sentence.
