#!/usr/bin/env python3
"""
Semi-deterministic scorer for the GitHub Issue Cascade skill.

Commands:
  score-batch --input classified_batch.json --out ranked_batch.json
  score-bucket --input classified_bucket.json --out rerank.json

The LLM should classify issues into controlled fields. This script computes scores,
sorts deterministically, and emits formats that cascade_state.py can consume.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Tuple

BASE_LETTERS = list("ABCDEFGHIJKLMNOPQRSTUVWXY")
ACTIONABLE = "ACTIONABLE"
STATUSES = {
    "ACTIONABLE",
    "BLOCKED",
    "NEEDS_BLOCKER",
    "NEEDS_SPLIT",
    "NEEDS_CLARIFICATION",
    "DUPLICATE_CANDIDATE",
}
SDLC_CLASSES = [
    "prd_spec",
    "user_journey",
    "domain_model",
    "schema_contract",
    "auth_rights_policy",
    "ux_view_design",
    "interface_adapter",
    "test_harness",
    "spike_research",
    "split_decomposition",
    "implementation_feature",
    "bug_fix",
    "integration_ops",
    "polish_refactor",
]
CLASS_ORDER = {name: idx for idx, name in enumerate(SDLC_CLASSES)}
SCORE_FIELDS = [
    "readiness",
    "prerequisite_power",
    "rework_prevention",
    "blocker_leverage",
    "reuse_surface",
    "milestone_demand",
    "effort_fit",
    "confidence",
]
DEFAULT_WEIGHTS = {
    "readiness": 2.0,
    "prerequisite_power": 3.0,
    "rework_prevention": 3.0,
    "blocker_leverage": 3.0,
    "reuse_surface": 1.5,
    "milestone_demand": 2.0,
    "effort_fit": 1.5,
    "confidence": 0.75,
}
DEFAULT_PENALTIES = {
    "NEEDS_CLARIFICATION": -8.0,
    "NEEDS_SPLIT": -7.0,
    "NEEDS_BLOCKER": -10.0,
    "BLOCKED": -12.0,
    "DUPLICATE_CANDIDATE": -12.0,
}


def load_json(path: str | Path) -> Any:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def write_json(path: str | Path, data: Any) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False, sort_keys=True)
        f.write("\n")


def clamp_score(value: Any, field: str, issue_number: int) -> int:
    try:
        score = int(value)
    except Exception as exc:
        raise ValueError(f"issue #{issue_number} score {field!r} must be integer 0-4") from exc
    if score < 0 or score > 4:
        raise ValueError(f"issue #{issue_number} score {field!r} out of range 0-4: {score}")
    return score


def normalize_item(raw: Dict[str, Any]) -> Dict[str, Any]:
    if "issue_number" not in raw:
        raise ValueError(f"item missing issue_number: {raw}")
    issue_number = int(raw["issue_number"])
    status = str(raw.get("status", ACTIONABLE)).upper()
    if status not in STATUSES:
        raise ValueError(f"issue #{issue_number} unknown status: {status}")
    sdlc_class = str(raw.get("sdlc_class", "spike_research"))
    if sdlc_class not in CLASS_ORDER:
        raise ValueError(f"issue #{issue_number} unknown sdlc_class: {sdlc_class}")
    scores_raw = raw.get("scores", {})
    scores = {field: clamp_score(scores_raw.get(field, 0), field, issue_number) for field in SCORE_FIELDS}
    return {
        "issue_number": issue_number,
        "title": str(raw.get("title", "")),
        "status": status,
        "sdlc_class": sdlc_class,
        "signals": list(raw.get("signals", [])),
        "scores": scores,
        "missing_prerequisite": raw.get("missing_prerequisite"),
        "known_blocker": raw.get("known_blocker"),
        "summary": str(raw.get("summary", "")),
        "rationale": str(raw.get("rationale", raw.get("why", ""))),
        "confidence": raw.get("confidence"),
    }


def weighted_score(item: Dict[str, Any], weights: Dict[str, float], penalties: Dict[str, float]) -> float:
    score = 0.0
    for field in SCORE_FIELDS:
        score += float(weights.get(field, 0.0)) * float(item["scores"].get(field, 0))
    score += float(penalties.get(item["status"], 0.0))
    return round(score, 3)


def rank_items(data: Dict[str, Any]) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    weights = dict(DEFAULT_WEIGHTS)
    weights.update(data.get("weights", {}) or {})
    penalties = dict(DEFAULT_PENALTIES)
    penalties.update(data.get("penalties", {}) or {})
    normalized = []
    for raw in data.get("items", []):
        item = normalize_item(raw)
        item["priority_score"] = weighted_score(item, weights, penalties)
        normalized.append(item)
    actionable = [x for x in normalized if x["status"] == ACTIONABLE]
    non_priority = [x for x in normalized if x["status"] != ACTIONABLE]
    actionable.sort(key=lambda x: (-x["priority_score"], CLASS_ORDER[x["sdlc_class"]], x["issue_number"]))
    non_priority.sort(key=lambda x: (-x["priority_score"], CLASS_ORDER[x["sdlc_class"]], x["issue_number"]))
    return actionable, non_priority


def cmd_score_batch(args: argparse.Namespace) -> int:
    data = load_json(args.input)
    actionable, non_priority = rank_items(data)
    if len(actionable) > len(BASE_LETTERS):
        raise ValueError(f"too many actionable items for one batch: {len(actionable)} > {len(BASE_LETTERS)}")
    ranked_items = []
    for idx, item in enumerate(actionable):
        out = dict(item)
        out["rank"] = BASE_LETTERS[idx]
        out["why"] = out.pop("rationale", "")
        ranked_items.append(out)
    for item in non_priority:
        item["why"] = item.pop("rationale", "")
    output = {
        "batch_id": data.get("batch_id", Path(args.input).stem),
        "items": ranked_items + non_priority,
        "ranked_issue_numbers": [x["issue_number"] for x in ranked_items],
        "non_priority_issue_numbers": [x["issue_number"] for x in non_priority],
    }
    write_json(args.out, output)
    print(f"wrote ranked batch: {args.out}")
    return 0


def cmd_score_bucket(args: argparse.Namespace) -> int:
    data = load_json(args.input)
    actionable, non_priority = rank_items(data)
    if non_priority and not args.allow_non_actionable:
        nums = [x["issue_number"] for x in non_priority]
        raise ValueError(f"bucket contains non-actionable issues; move them out first or pass --allow-non-actionable: {nums}")
    output = {
        "bucket": data.get("bucket", "A"),
        "ranked_issue_numbers": [x["issue_number"] for x in actionable],
        "scored_items": actionable,
        "non_priority": non_priority,
    }
    write_json(args.out, output)
    print(f"wrote rerank: {args.out}")
    return 0


def main(argv: List[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Score classified GitHub issues for the bucketed demotion cascade")
    sub = parser.add_subparsers(dest="command", required=True)

    score_batch = sub.add_parser("score-batch", help="score a classified initial batch and assign A-Y ranks")
    score_batch.add_argument("--input", required=True)
    score_batch.add_argument("--out", required=True)
    score_batch.set_defaults(func=cmd_score_batch)

    score_bucket = sub.add_parser("score-bucket", help="score a classified active bucket and emit rerank order")
    score_bucket.add_argument("--input", required=True)
    score_bucket.add_argument("--out", required=True)
    score_bucket.add_argument("--allow-non-actionable", action="store_true")
    score_bucket.set_defaults(func=cmd_score_bucket)

    args = parser.parse_args(argv)
    try:
        return int(args.func(args))
    except Exception as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
