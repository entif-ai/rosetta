#!/usr/bin/env python3
"""
Deterministic state helper for the GitHub Issue Cascade skill.

Commands:
  build --batch-files batch01.json batch02.json --out state.json
  apply --state state.json --rerank rerank.json --out new_state.json --winner-out winner.json

This script is optional. The skill can be run with Markdown tables only.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from copy import deepcopy
from pathlib import Path
from typing import Any, Dict, Iterable, List, Tuple

ACTIVE_STATUSES = {"ACTIONABLE"}
NON_PRIORITY_MAP = {
    "BLOCKED": "blocked",
    "NEEDS_BLOCKER": "needs_blocker",
    "NEEDS_SPLIT": "needs_split",
    "NEEDS_CLARIFICATION": "needs_clarification",
    "DUPLICATE_CANDIDATE": "duplicate_candidate",
}
BASE_LETTERS = list("ABCDEFGHIJKLMNOPQRSTUVWXY")
RANK_RE = re.compile(r"^([A-Y])([1-9][0-9]*)?$")


def load_json(path: str | Path) -> Any:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def write_json(path: str | Path, data: Any) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False, sort_keys=True)
        f.write("\n")


def rank_index(rank: str) -> int:
    """Return zero-based index in ladder A..Y,A2..Y2,A3.."""
    match = RANK_RE.match(rank)
    if not match:
        raise ValueError(f"invalid rank bucket: {rank!r}")
    letter, tier_text = match.groups()
    tier = int(tier_text) if tier_text else 1
    if tier < 1:
        raise ValueError(f"invalid rank tier in bucket: {rank!r}")
    return (tier - 1) * len(BASE_LETTERS) + BASE_LETTERS.index(letter)


def index_rank(index: int) -> str:
    if index < 0:
        raise ValueError("rank index cannot be negative")
    tier = index // len(BASE_LETTERS) + 1
    letter = BASE_LETTERS[index % len(BASE_LETTERS)]
    return letter if tier == 1 else f"{letter}{tier}"


def ensure_state_shape(state: Dict[str, Any]) -> Dict[str, Any]:
    state.setdefault("bucket_capacity", 25)
    state.setdefault("buckets", {})
    for key in ["blocked", "needs_blocker", "needs_split", "needs_clarification", "duplicate_candidate", "done"]:
        state.setdefault(key, [])
    return state


def normalize_item(item: Dict[str, Any], batch_id: str | None = None) -> Dict[str, Any]:
    if "issue_number" not in item:
        raise ValueError(f"item missing issue_number: {item}")
    normalized = {
        "issue_number": int(item["issue_number"]),
        "title": str(item.get("title", "")),
        "status": str(item.get("status", "ACTIONABLE")).upper(),
        "summary": str(item.get("summary", "")),
        "why": str(item.get("why", "")),
        "known_blocker": item.get("known_blocker"),
        "confidence": item.get("confidence"),
    }
    # Preserve optional scoring/classification fields from score_issues.py.
    for optional_key in [
        "sdlc_class",
        "signals",
        "scores",
        "priority_score",
        "missing_prerequisite",
    ]:
        if optional_key in item:
            normalized[optional_key] = item[optional_key]
    if batch_id is not None:
        normalized["batch_id"] = str(batch_id)
    if item.get("rank") is not None:
        normalized["rank"] = str(item["rank"]).upper()
    return normalized


def add_to_bucket(state: Dict[str, Any], bucket: str, item: Dict[str, Any]) -> str:
    capacity = int(state.get("bucket_capacity", 25))
    bucket_index = rank_index(bucket)
    while True:
        target = index_rank(bucket_index)
        state["buckets"].setdefault(target, [])
        if len(state["buckets"][target]) < capacity:
            item = deepcopy(item)
            item["bucket"] = target
            state["buckets"][target].append(item)
            return target
        bucket_index += 1


def remove_issue_from_bucket(state: Dict[str, Any], bucket: str, issue_number: int) -> Dict[str, Any]:
    items = state["buckets"].get(bucket, [])
    for idx, item in enumerate(items):
        if int(item["issue_number"]) == int(issue_number):
            return items.pop(idx)
    raise ValueError(f"issue #{issue_number} not found in bucket {bucket}")


def build_state(batch_files: Iterable[str], capacity: int) -> Dict[str, Any]:
    state: Dict[str, Any] = ensure_state_shape({"bucket_capacity": capacity, "buckets": {}})
    seen: set[int] = set()
    for path in batch_files:
        batch = load_json(path)
        batch_id = batch.get("batch_id") or Path(path).stem
        for raw in batch.get("items", []):
            item = normalize_item(raw, batch_id=batch_id)
            issue_number = item["issue_number"]
            if issue_number in seen:
                raise ValueError(f"duplicate issue in batch files: #{issue_number}")
            seen.add(issue_number)

            status = item["status"]
            if status in ACTIVE_STATUSES:
                rank = item.get("rank")
                if not rank:
                    raise ValueError(f"ACTIONABLE issue #{issue_number} missing rank")
                rank_index(rank)  # validate
                add_to_bucket(state, rank, item)
            elif status in NON_PRIORITY_MAP:
                state[NON_PRIORITY_MAP[status]].append(item)
            else:
                raise ValueError(f"unknown status for issue #{issue_number}: {status}")
    return state


def apply_rerank(state: Dict[str, Any], rerank: Dict[str, Any]) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    state = ensure_state_shape(deepcopy(state))
    bucket = str(rerank["bucket"]).upper()
    ranked = [int(x) for x in rerank.get("ranked_issue_numbers", [])]
    if not ranked:
        raise ValueError("rerank ranked_issue_numbers cannot be empty")
    if bucket not in state["buckets"] or not state["buckets"][bucket]:
        raise ValueError(f"bucket {bucket} is empty or missing")

    bucket_issue_numbers = {int(item["issue_number"]) for item in state["buckets"][bucket]}
    ranked_set = set(ranked)
    if ranked_set != bucket_issue_numbers:
        missing = sorted(bucket_issue_numbers - ranked_set)
        extra = sorted(ranked_set - bucket_issue_numbers)
        raise ValueError(f"rerank must include exactly all issues in bucket {bucket}; missing={missing}, extra={extra}")

    base_index = rank_index(bucket)
    winner_item = remove_issue_from_bucket(state, bucket, ranked[0])
    winner_item["selected_from_bucket"] = bucket
    state["done"].append(winner_item)

    moves = []
    for finish_position, issue_number in enumerate(ranked[1:], start=2):
        item = remove_issue_from_bucket(state, bucket, issue_number)
        target_rank = index_rank(base_index + finish_position - 1)
        actual_target = add_to_bucket(state, target_rank, item)
        moves.append({
            "issue_number": issue_number,
            "finish": finish_position,
            "target_bucket": target_rank,
            "actual_bucket": actual_target,
        })

    # Remove empty bucket key only if it is beyond first tier? Keep first tier keys readable.
    winner = {
        "issue_number": winner_item["issue_number"],
        "title": winner_item.get("title", ""),
        "selected_from_bucket": bucket,
        "moves": moves,
    }
    return state, winner


def cmd_build(args: argparse.Namespace) -> int:
    state = build_state(args.batch_files, args.capacity)
    write_json(args.out, state)
    print(f"built state: {args.out}")
    return 0


def cmd_apply(args: argparse.Namespace) -> int:
    state = load_json(args.state)
    rerank = load_json(args.rerank)
    new_state, winner = apply_rerank(state, rerank)
    write_json(args.out, new_state)
    if args.winner_out:
        write_json(args.winner_out, winner)
    else:
        print(json.dumps(winner, indent=2, ensure_ascii=False, sort_keys=True))
    return 0


def main(argv: List[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="GitHub issue bucketed demotion cascade helper")
    sub = parser.add_subparsers(dest="command", required=True)

    build = sub.add_parser("build", help="build state from batch JSON files")
    build.add_argument("--batch-files", nargs="+", required=True)
    build.add_argument("--out", required=True)
    build.add_argument("--capacity", type=int, default=25)
    build.set_defaults(func=cmd_build)

    apply = sub.add_parser("apply", help="apply active bucket rerank to state")
    apply.add_argument("--state", required=True)
    apply.add_argument("--rerank", required=True)
    apply.add_argument("--out", required=True)
    apply.add_argument("--winner-out")
    apply.set_defaults(func=cmd_apply)

    args = parser.parse_args(argv)
    try:
        return int(args.func(args))
    except Exception as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
