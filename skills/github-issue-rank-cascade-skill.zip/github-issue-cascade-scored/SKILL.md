---
name: github-issue-cascade
description: dead-simple github issue prioritization by bucketed demotion cascade. use when ranking a large backlog of github issues in small batches, especially with weaker or low-context models such as minimax, openclaw, hermes, codex, or lightweight subagents. supports fixed 25-issue batch triage, a-y active priority buckets, blocked/needs-blocker separation, and one-bucket-at-a-time reranking to pick the next issue without global all-pairs comparisons.
---

# GitHub Issue Cascade

## Purpose

Use this skill to prioritize a large GitHub issue backlog with the smallest reliable amount of model reasoning. The method is a bucketed demotion cascade: first rank fixed batches of up to 25 issues, then repeatedly rerank only the current highest non-empty priority bucket to choose one next issue.

This skill is intentionally simple. Do not require Rosetta, graph databases, advanced memory, embeddings, all-pairs comparisons, or a full project-management system.

## Core Rules

1. Work from a frozen issue manifest whenever possible: open GitHub issues, oldest to newest, excluding pull requests unless the user explicitly includes them.
2. Use batches of at most 25 issues.
3. Rank actionable issues with letters `A` through `Y` only.
4. Do not use `Z` as a normal priority rank. Treat blocked or unrankable items as separate states: `BLOCKED`, `NEEDS_BLOCKER`, `NEEDS_SPLIT`, `NEEDS_CLARIFICATION`, or `DUPLICATE_CANDIDATE`.
5. In each initial batch, rank issues only against the other issues in that batch.
6. For each work decision, rerank only the current highest non-empty bucket.
7. The rerank winner is the next issue to work.
8. Demote every losing issue by its finish position: 2nd place moves down 1 bucket, 3rd place moves down 2 buckets, and so on.
9. If a target bucket is full, spill the issue to the next lower bucket.
10. Never compare more than 25 issues in one model pass unless the user explicitly overrides this constraint.
11. Use the ranking rubric in `references/ranking-rubric.md` for every initial batch triage and active bucket rerank. Do not invent a new priority strategy per run.
12. When a runtime can execute scripts, prefer scored classification mode: have the model classify each issue using `references/scoring-matrix.md`, then run `scripts/score_issues.py` to compute ranks deterministically.

## Ranking Ladder

The active rank ladder starts:

`A, B, C, D, E, F, G, H, I, J, K, L, M, N, O, P, Q, R, S, T, U, V, W, X, Y`

If lower buckets are needed, continue with:

`A2, B2, C2 ... Y2, A3, B3 ...`

Use `BLOCKED`/`NEEDS_BLOCKER` instead of `Z` unless an external tool forces a single-letter scheme. If forced to use a single-letter scheme, map all blocked/unrankable issues to `Z` in the display only, not in the internal priority ladder.

## Workflow

### 1. Freeze the manifest

Get a stable list of open issue numbers ordered oldest to newest. If using GitHub tools, filter out pull requests. If using pasted data, ask for or infer a fixed list from the pasted issue numbers.

Create batches of up to 25 issues:

- batch 01: issues 1-25
- batch 02: issues 26-50
- continue until all issues are assigned

### 2. Initial batch triage

For each batch, inspect only the issue title, body, labels, dependency clues, and comments needed to resolve obvious blockers.

Use the rubric in `references/ranking-rubric.md` as the ranking standard. Prefer issues that reduce rework, unblock sequencing, are spec-ready, create reusable primitives, or produce immediate leverage. Move vague, blocked, overbroad, or research-dependent issues into non-priority states instead of forcing them into A-Y.

Output a compact table:

| Rank | Issue | Status | Title | Summary | Why this rank | Known blocker | Confidence |
|---|---:|---|---|---|---|---|---:|

Status values:

- `ACTIONABLE`: can be worked now
- `BLOCKED`: known blocker issue exists
- `NEEDS_BLOCKER`: appears blocked, but blocker issue is missing or unknown
- `NEEDS_SPLIT`: too broad to complete as one issue
- `NEEDS_CLARIFICATION`: insufficient information
- `DUPLICATE_CANDIDATE`: may duplicate another issue

Only `ACTIONABLE` issues receive A-Y ranks. Put all others in the notes section.

### 3. Build buckets

Place every initial `A` into the A bucket, every initial `B` into the B bucket, and so on. Put blocked/unrankable issues in their separate non-priority state.

### 4. Pick the next issue

Find the highest non-empty bucket. Rerank only the issues in that bucket.

Rerank output:

| Finish | Issue | Title | Why this finish | New destination |
|---:|---:|---|---|---|
| 1 | #123 | ... | best next issue | DO_NOW |
| 2 | #456 | ... | close, but less urgent | next bucket |
| 3 | #789 | ... | lower leverage | two buckets down |

The first-place issue is the next issue to work. Demote all other issues according to finish position.

### 5. Repeat only after the selected issue is done or intentionally skipped

Do not rerank multiple buckets in one planning pass unless the user asks for a larger planning queue. The default cadence is one bounded rerank -> one chosen issue.

## Ranking Rubric

Use `references/ranking-rubric.md` whenever deciding order. The default stance is SDLC dependency-first: prefer missing PRDs, user journeys, domain models, schemas, contracts, AuthN/AuthZ models, rights matrices, UX view requirements, adapter interfaces, tests, and other prerequisite artifacts before downstream implementation that would guess at them. Demote cart-before-horse implementation into `NEEDS_BLOCKER`, `NEEDS_SPLIT`, or `NEEDS_CLARIFICATION` when the required upstream artifact does not exist.

## Small-Model Reliability Rules

When running on weaker or low-context models:

- Use terse issue summaries.
- Avoid philosophical architecture commentary.
- Do not invent blockers.
- Do not search outside the issue unless instructed.
- Prefer explicit labels, issue links, dependency fields, and direct statements over inference.
- If uncertain, classify as `NEEDS_CLARIFICATION` or `NEEDS_BLOCKER` instead of guessing.
- Output the required table only.
- Keep rationales to one sentence.

## Optional Script

If a Python runtime is available, use `scripts/score_issues.py` to score classified issue batches/buckets, then use `scripts/cascade_state.py` to build bucket state from ranked batch JSON files and apply rerank results deterministically. See `references/scoring-matrix.md` and `references/json-formats.md` for the expected JSON formats.

Preferred script flow:

1. Ask the model to output classified issue JSON using controlled `sdlc_class`, `status`, signal tags, and 0-4 score fields.
2. Run `scripts/score_issues.py score-batch --input classified_batch.json --out ranked_batch.json`.
3. Run `scripts/cascade_state.py build --batch-files ranked_batch*.json --out state.json`.
4. For active bucket rerank, classify/score only the current bucket, run `score_issues.py score-bucket`, then run `cascade_state.py apply`.

## References

- `references/cascade-protocol.md`: exact cascade algorithm and examples.
- `references/ranking-rubric.md`: standardized issue ranking rubric for initial batch triage and active bucket reranking.
- `references/scoring-matrix.md`: controlled classifications, 0-4 score fields, default weights, and tuning guidance for semi-deterministic ranking.
- `references/prompts.md`: copy-paste prompts for batch triage, scored classification, and bucket reranking.
- `references/json-formats.md`: optional JSON formats for script-based state management.
